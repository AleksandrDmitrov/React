import React from 'react';
import Greeting from './components/Greeting';

class App extends Comments {
  constructor(props){
    super(props);
this.state = {
  userName: 'anonymous'
};
  }
  render(){
    const { userName}= this.state;
    return <Greeting name={userName}>;
  }
}
export default App;
